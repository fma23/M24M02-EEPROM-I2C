/**
  ******************************************************************************
  * File Name          : main.c
	* Author             : Farid Mabr
  * Description        : Main program body
  ******************************************************************************/

//data sheet is at: https://www.st.com/resource/en/datasheet/m24m02-dr.pdf

// As per data sheet: The 256 Kbytes (2 Mb) are addressed with 18 address bits, 
// the 16 lower address bits being defined by the two address bytes and the most
// significant address bits (A17, A16) being included in the Device Select code as in table4
//page 14 of datasheet.

//Read operations are performed independently of the state of the Write Control (WC) signal.

//http://www.ti.com/lit/an/slva704/slva704.pdf

#include "main.h"
#include <stdbool.h>



TIM_HandleTypeDef Tim3Handle;
uint32_t uwPrescalerValue = 0;
volatile bool I2C_Wr_Flag=false; 
volatile bool I2C_Rd_Flag=false; 




void SystemClock_Config(void);
void Error_Handler(void);

int main(void)
{

  HAL_Init();

  SystemClock_Config();
	
	Configure_GPIOs();
	
	/*TIMER3 Config */
	Timer3_Interrupt_Config();

  I2C_Config();
	
	Write_EEPROM();
  HAL_Delay(5);
	Read_EEPROM();
	HAL_Delay(5);
}




/** Timer3 configuration
*/


void Timer3_Interrupt_Config(void)
{
	
	 /* Compute the prescaler value to have TIM3 counter clock equal to 10 KHz */
  uwPrescalerValue = (uint32_t) ((SystemCoreClock /2) / 10000) - 1;
  
  /* Set TIMx instance */
  Tim3Handle.Instance = TIM3;
   
  /* Initialize TIM3 peripheral as follow:
       + Period = 10000 - 1
       + Prescaler = ((SystemCoreClock/2)/10000) - 1
       + ClockDivision = 0
       + Counter direction = Up
  */
  Tim3Handle.Init.Period = 5000 - 1;   //expires at 500ms intervals
  Tim3Handle.Init.Prescaler = uwPrescalerValue;
  Tim3Handle.Init.ClockDivision = 0;
  Tim3Handle.Init.CounterMode = TIM_COUNTERMODE_UP;
	
	if(HAL_TIM_Base_Init(&Tim3Handle) != HAL_OK)
  {
    /* Initialization Error */
    Error_Handler();
  }
  
	/*Start the TIM Base generation in interrupt mode */
  if(HAL_TIM_Base_Start_IT(&Tim3Handle) != HAL_OK)
  {
    /* Starting Error */
    Error_Handler();
  }
	
	
}
/** System Clock Configuration
  * @brief  System Clock Configuration
  *         The system Clock is configured as follow : 
  *            System Clock source            = PLL (HSE)
  *            SYSCLK(Hz)                     = 168000000
  *            HCLK(Hz)                       = 168000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 4
  *            APB2 Prescaler                 = 2
  *            HSE Frequency(Hz)              = 8000000
  *            PLL_M                          = 25
  *            PLL_N                          = 336
  *            PLL_P                          = 2
  *            PLL_Q                          = 7
  *            VDD(V)                         = 3.3
  *            Main regulator output voltage  = Scale1 mode
  *            Flash Latency(WS)              = 5
  * @param  None
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* Enable Power Control clock */
  __PWR_CLK_ENABLE();

  /* The voltage scaling allows optimizing the power consumption when the device is 
     clocked below the maximum system frequency, to update the voltage scaling value 
     regarding system frequency refer to product datasheet.  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /* Enable HSE Oscillator and activate PLL with HSE as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  
  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;  
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);


}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{

}

#endif
	







/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
