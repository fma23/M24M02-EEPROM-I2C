#include "main.h"


void Clear_I2C_RW(void); 
void Set_I2C_RW(void); 

I2C_HandleTypeDef I2cHandle;

uint8_t I2C_DevSelectAddress_WR=0xA0;                 // "10100000, WR bit =0; Chip Enable= 0; bit16=0;bit17=0
uint8_t I2C_DevSelectAddress_RD=0xA0;                 // "10100001, WR bit =1; Chip Enable= 0; bit16=0;bit17=0
volatile uint16_t I2CMemAddress=0;        
uint8_t WrBuffer[3] ={12,13,14};                      // write data from this buffer to the EEPROM                     
uint8_t RdBuffer[3] ={0,0,0};                         // read data to this buffer

void I2c_Error_Handler(void)
{
  while(1)
  {
  }
}

/* Configure the I2C peripheral */
void I2C_Config(void){

  I2cHandle.Instance             = I2C1;
  
  I2cHandle.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
  I2cHandle.Init.ClockSpeed      = 400000;
  I2cHandle.Init.DualAddressMode = I2C_DUALADDRESS_DISABLED;
  I2cHandle.Init.DutyCycle       = I2C_DUTYCYCLE_16_9;
  I2cHandle.Init.GeneralCallMode = I2C_GENERALCALL_DISABLED;
  I2cHandle.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLED;
  I2cHandle.Init.OwnAddress1     = 0x0A;
  I2cHandle.Init.OwnAddress2     = 0xFE;
	
	if(HAL_I2C_Init(&I2cHandle) != HAL_OK)
  {
    /* Initialization Error */
    I2c_Error_Handler();    
  }
}

void Write_EEPROM(void)
{
	
	I2CMemAddress=0;

	/*start writing to the EEPROM */
	//RW set low: write enable
	HAL_GPIO_WritePin(GPIOA, EEPROM_WR_EN, GPIO_PIN_RESET); 

  // As per data sheet: The 256 Kbytes (2 Mb) are addressed with 18 address bits, 
	// the 16 lower address bits being defined by the two address bytes and the most
  // significant address bits (A17, A16) being included in the Device Select code.
	
	I2CMemAddress=0;

	 //Parameters: I2C handle,DevAddress,MemAddress,MemAddSize,data buffer pointer,Size,Timeout
	 HAL_I2C_Mem_Write(&I2cHandle, I2C_DevSelectAddress_WR,I2CMemAddress, 2,WrBuffer,3,100);    

	 HAL_GPIO_WritePin(GPIOA, EEPROM_WR_EN, GPIO_PIN_SET); 	//DISABLE writing to EEPROM
}

void Read_EEPROM(void)
{	

	I2CMemAddress=0;			
					
	//Parameters: I2C handle,DevAddress,MemAddress,MemAddSize,data buffer pointer,Size,Timeout
	HAL_I2C_Mem_Read(&I2cHandle,I2C_DevSelectAddress_RD, I2CMemAddress, 2, RdBuffer, 3, 100); 
	
	HAL_Delay(5);
	 	
}
