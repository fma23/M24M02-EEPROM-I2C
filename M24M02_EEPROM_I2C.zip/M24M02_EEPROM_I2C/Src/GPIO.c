#include "main.h"


void Configure_GPIOs(void) 
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	
	/* Enable both GPIO clock */
	__GPIOI_CLK_ENABLE();
  __GPIOA_CLK_ENABLE();

	/* Green LED   */
	GPIO_InitStruct.Pin       = Green_LED|Blue_LED ;
	GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull      = GPIO_PULLUP;
	GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;

  HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);
	
	/* define PA10 for EEPROM WR as an input  */
  GPIO_InitStruct.Pin       = EEPROM_WR_EN;
  GPIO_InitStruct.Mode      = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull      = GPIO_PULLUP;
  GPIO_InitStruct.Speed     = GPIO_SPEED_FAST;
	
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
}